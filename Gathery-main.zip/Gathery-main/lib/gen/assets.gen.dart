/// GENERATED CODE - DO NOT MODIFY BY HAND
/// *****************************************************
///  FlutterGen
/// *****************************************************

// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: directives_ordering,unnecessary_import,implicit_dynamic_list_literal,deprecated_member_use

class $AssetsIconsGen {
  const $AssetsIconsGen();

  /// File path: assets/icons/iconPlus.svg
  String get iconPlus => 'assets/icons/iconPlus.svg';

  /// List of all assets
  List<String> get values => [iconPlus];
}

class Assets {
  Assets._();

  static const $AssetsIconsGen icons = $AssetsIconsGen();
}
