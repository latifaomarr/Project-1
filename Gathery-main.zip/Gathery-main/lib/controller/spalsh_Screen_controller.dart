import 'package:get/get.dart';

abstract class JoinEventController extends GetxController {

}

class JoinEventControllerImp extends JoinEventController  {

}
