import 'package:flutter/material.dart';

class AppColor {
  static const Color primary = Color(0xff2fb4ff);
  static const Color secondry = Color(0xff778CEFF);
  static const Color third = Color(0xffE3F5FF);
  static const Color white = Colors.white;
}
