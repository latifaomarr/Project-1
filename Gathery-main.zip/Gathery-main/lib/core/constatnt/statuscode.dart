enum StatusRequest {
  none,
  success,
  loading,
  failure,
  serverFailure,
  exceptionFailure,
  offlineFailure,
}
