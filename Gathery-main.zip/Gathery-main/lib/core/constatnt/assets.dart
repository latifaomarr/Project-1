class ImageAsset {
  static const String test = "assets/images/test1.png";
  static const String person = "assets/images/person.png";

}